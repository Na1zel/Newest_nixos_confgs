{ pkgs, ... }:

{
  environment.systemPackages = with pkgs; [

    # Office
    libreoffice

    # Image / creative / 3D
    krita gimp darktable upscaler
    imv

    # Music
    cmus

    # Video editing
    kdePackages.kdenlive

    # Communication
    ayugram-desktop vesktop

    # Text-editor
    lite-xl

    # Torrents
    transmission_4-gtk

    # KDE utilities
    kdePackages.partitionmanager kdePackages.isoimagewriter
    kdePackages.qt6ct
    #kdePackages.qtstyleplugin-kvantum #добавить если надо
    kdePackages.breeze-icons
    pcmanfm xarchiver ffmpegthumbnailer
  ];
}
