{ pkgs, ... }:

{
  home.packages = with pkgs; [
    basedpyright
    zoxide
    eza
    lazygit
    #удали Wireplumber из audio
  ];
}
