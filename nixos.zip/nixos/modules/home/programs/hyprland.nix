{ config, pkgs, ... }:

{
  wayland.windowManager.hyprland = {
    enable = true;
    systemd.enable = false;
    package = null;
    portalPackage = null;
    xwayland.enable = true;
    configType = "lua";
    settings = {};
    extraConfig = ''
      -- monitor
      hl.monitor({ output = "DP-3", mode = "1920x1080@165", position = "0x0", scale = 1 })

      -- env
      hl.env("QT_QPA_PLATFORMTHEME", "qt6ct")
      hl.env("QT_STYLE_OVERRIDE", "Darkly")
      hl.env("XCURSOR_THEME", "Simp1e-Dark")
      hl.env("XCURSOR_SIZE", "24")
      hl.env("HYPRCURSOR_THEME", "Simp1e-Dark")
      hl.env("HYPRCURSOR_SIZE", "24")

      -- config
      local OPACITY = 0.80
      hl.config({
        general = { layout = "dwindle", gaps_in = 5, gaps_out = 10, border_size = 2 },
        decoration = {
          rounding = 0,
          active_opacity = OPACITY,
          inactive_opacity = OPACITY,
          fullscreen_opacity = 1.0,
          blur = {
            enabled = true,
            size = 6,
            passes = 3,
            noise = 0.02,
            contrast = 0.9,
            brightness = 0.9,
            vibrancy = 0.17,
            popups = true,
          },
        },
        input = {
          kb_layout = "us,ru",
          kb_options = "grp:alt_shift_toggle",
          accel_profile = "flat",
          sensitivity = 0,
          repeat_delay = 300,
          repeat_rate = 25,
        },
        misc = { vrr = 1 },
      })

      -- dynamic color
      require("noctalia").apply_theme()

      -- animations
      hl.curve("mango",      { type = "bezier", points = { {0.46, 1.0}, {0.29, 1} } })
      hl.curve("mangoClose", { type = "bezier", points = { {0.08, 0.92}, {0, 1} } })
      hl.animation({ leaf = "global",     enabled = true, speed = 5,   bezier = "mango" })
      hl.animation({ leaf = "windows",    enabled = true, speed = 5,   bezier = "mango" })
      hl.animation({ leaf = "windowsIn",  enabled = true, speed = 4,   bezier = "mango",      style = "slide" })
      hl.animation({ leaf = "windowsOut", enabled = true, speed = 8,   bezier = "mangoClose", style = "slide" })
      hl.animation({ leaf = "fadeIn",     enabled = true, speed = 4,   bezier = "mango" })
      hl.animation({ leaf = "fadeOut",    enabled = true, speed = 8,   bezier = "mangoClose" })
      hl.animation({ leaf = "workspaces", enabled = true, speed = 3.5, bezier = "mango",      style = "slide" })
      hl.animation({ leaf = "layers",     enabled = true, speed = 4,   bezier = "mango",      style = "slide" })
      hl.animation({ leaf = "border",     enabled = false })

      -- window rules (float-new должно идти первым)
      local float_new = hl.window_rule({ name = "float-new", match = { class = ".*" }, float = true, center = true })
      float_new:set_enabled(false)
      local float_new_on = false

      hl.window_rule({ name = "suppress-maximize-events", match = { class = ".*" }, suppress_event = "maximize" })
      hl.window_rule({ match = { class = "^(thunar|Thunar)$", title = "Preferences" }, float = true, center = true, size = { 550, 500 } })
      hl.window_rule({ match = { class = "^(thunar|Thunar)$", title = "^(Rename.*)$" }, float = true, move = {"cursor_x-(window_w*0.5)", "cursor_y-(window_h*0.5)"}, size = { 300, 100 } })
      hl.window_rule({ match = { class = "firefox", title = ".*Save.*" }, float = true, center = true })
      hl.window_rule({ match = { class = "firefox", title = ".*Open.*" }, float = true, center = true })
      hl.window_rule({ match = { class = "DesktopEditors" }, float = true, center = true })
      hl.window_rule({ match = { class = "xdg-desktop-portal-gtk", title = ".*Open.*" }, size = {"monitor_w * 0.5", "monitor_h * 0.5"}, float = true, center = true })

      -- apps
      hl.bind("SUPER + RETURN", hl.dsp.exec_cmd("kitty"))
      hl.bind("SUPER + T", hl.dsp.exec_cmd("kitty"))
      hl.bind("SUPER + E", hl.dsp.exec_cmd("pcmanfm"))

      -- windows
      hl.bind("SUPER + Q", hl.dsp.window.close())
      hl.bind("SUPER + W", hl.dsp.window.float({ action = "toggle" }))
      hl.bind("SUPER + F", hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }))
      hl.bind("SUPER + SHIFT + F", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
      hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true })
      hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })

      -- новые окна плавающие
      hl.bind("SUPER + SHIFT + W", function()
        float_new_on = not float_new_on
        float_new:set_enabled(float_new_on)
      end)

      -- все окна плавающие / в мозаику
      hl.bind("SUPER + CTRL + W", function()
        local tiled = hl.get_windows({ floating = false, mapped = true })
        local action = (#tiled > 0) and "set" or "unset"
        for _, w in ipairs(hl.get_windows({ mapped = true })) do
          hl.dispatch(hl.dsp.window.float({ action = action, window = w }))
        end
      end)

      -- переключение окон
      hl.bind("ALT + TAB", hl.dsp.exec_cmd("noctalia msg window-switcher"))
      hl.bind("SUPER + Tab", function()
        hl.dispatch(hl.dsp.window.cycle_next({}))
        hl.dispatch(hl.dsp.window.bring_to_top())
      end)
      hl.bind("SUPER + SHIFT + Tab", function()
        hl.dispatch(hl.dsp.window.alter_zorder({ mode = "bottom" }))
        hl.dispatch(hl.dsp.window.cycle_next({ next = false }))
      end)

      -- фокус и перемещение (vim + стрелки)
      local dirs = { H = "left", J = "down", K = "up", L = "right", left = "left", right = "right", up = "up", down = "down" }
      for key, dir in pairs(dirs) do
        hl.bind("SUPER + " .. key, hl.dsp.focus({ direction = dir }))
        hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ direction = dir }))
      end

      -- workspaces
      hl.bind("SUPER + D", hl.dsp.focus({ workspace = "empty" }))
      hl.bind("SUPER + Page_Up", hl.dsp.focus({ workspace = "+1" }))
      hl.bind("SUPER + Page_Down", hl.dsp.focus({ workspace = "-1" }))
      hl.bind("SUPER + SHIFT + Page_Up", hl.dsp.window.move({ workspace = "+1" }))
      hl.bind("SUPER + SHIFT + Page_Down", hl.dsp.window.move({ workspace = "-1" }))
      hl.bind("SUPER + C", hl.dsp.workspace.toggle_special("scratchpad"))
      hl.bind("SUPER + SHIFT + C", hl.dsp.window.move({ workspace = "special:scratchpad" }))
      for i = 1, 9 do
        hl.bind("SUPER + " .. i, hl.dsp.focus({ workspace = tostring(i) }))
        hl.bind("SUPER + SHIFT + " .. i, hl.dsp.window.move({ workspace = tostring(i) }))
      end

      -- layouts: SUPER+CTRL+1..4
      local layouts = { "dwindle", "master", "scrolling", "monocle" }
      for i, name in ipairs(layouts) do
        hl.bind("SUPER + CTRL + " .. i, function()
          hl.config({ general = { layout = name } })
        end)
      end

      -- layout-зависимые бинды
      local function layout_bind(bind_table)
        return function ()
          local workspace = hl.get_active_special_workspace() or hl.get_active_workspace()
          if not workspace then return end
          local layout = workspace.tiled_layout
          if bind_table[layout] then
            hl.dispatch(bind_table[layout])
          end
        end
      end

      hl.bind("SUPER + comma", layout_bind({ master = hl.dsp.layout("mfact -0.01"), scrolling = hl.dsp.layout("colresize -0.01") }), { repeating = true })
      hl.bind("SUPER + period", layout_bind({ master = hl.dsp.layout("mfact +0.01"), scrolling = hl.dsp.layout("colresize +0.01") }), { repeating = true })
      hl.bind("SUPER + SHIFT + comma", layout_bind({ master = hl.dsp.layout("orientationprev"), scrolling = hl.dsp.layout("swapcol l") }))
      hl.bind("SUPER + SHIFT + period", layout_bind({ master = hl.dsp.layout("orientationnext"), scrolling = hl.dsp.layout("swapcol r") }))
      hl.bind("SUPER + slash", layout_bind({ master = hl.dsp.layout("addmaster"), scrolling = hl.dsp.layout("consume") }))
      hl.bind("SUPER + SHIFT + slash", layout_bind({ master = hl.dsp.layout("removemaster"), scrolling = hl.dsp.layout("expel") }))

      -- прозрачность (SUPER+G) и блюр (SUPER+SHIFT+G)
      local opacity_on = true
      hl.bind("SUPER + G", function()
        opacity_on = not opacity_on
        local value = opacity_on and OPACITY or 1.0
        hl.config({ decoration = { active_opacity = value, inactive_opacity = value } })
      end)

      local blur_on = true
      hl.bind("SUPER + SHIFT + G", function()
        blur_on = not blur_on
        hl.config({ decoration = { blur = { enabled = blur_on } } })
      end)

      -- noctalia
      hl.bind("SUPER + A", hl.dsp.exec_cmd("noctalia msg panel-toggle launcher"))
      hl.bind("SUPER + M", hl.dsp.exec_cmd("noctalia msg panel-toggle control-center"))
      hl.bind("SUPER + S", hl.dsp.exec_cmd("noctalia msg panel-toggle wallpaper"))
      hl.bind("SUPER + V", hl.dsp.exec_cmd("noctalia msg panel-toggle clipboard"))
      hl.bind("SUPER + SHIFT + B", hl.dsp.exec_cmd("noctalia msg bar-toggle"))
      hl.bind("SUPER + CTRL + L", hl.dsp.exec_cmd("noctalia msg session lock"))
      hl.bind("CTRL + ALT + Delete", hl.dsp.exec_cmd("noctalia msg panel-toggle session"))

      -- звук, яркость, скриншоты, XF86
      hl.bind("SUPER + F9", hl.dsp.exec_cmd("noctalia msg volume-mute"))
      hl.bind("SUPER + F10", hl.dsp.exec_cmd("noctalia msg volume-down 5"), { repeating = true })
      hl.bind("SUPER + F11", hl.dsp.exec_cmd("noctalia msg volume-up 5"), { repeating = true })
      hl.bind("XF86AudioMicMute", hl.dsp.exec_cmd("noctalia msg mic-mute"))
      hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("noctalia msg brightness-down"))
      hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("noctalia msg brightness-up"))
      hl.bind("Print", hl.dsp.exec_cmd("noctalia msg screenshot-fullscreen"))
      hl.bind("XF86SelectiveScreenshot", hl.dsp.exec_cmd("noctalia msg screenshot-region"))
      hl.bind("XF86Display", hl.dsp.exec_cmd("noctalia msg panel-toggle control-center"))
      hl.bind("XF86NotificationCenter", hl.dsp.exec_cmd("noctalia msg power-cycle"))
      hl.bind("XF86PickupPhone", hl.dsp.exec_cmd("noctalia msg bluetooth-toggle"))
      hl.bind("XF86HangupPhone", hl.dsp.exec_cmd("noctalia msg panel-toggle session"))
      hl.bind("XF86Favorites", hl.dsp.exec_cmd("noctalia msg settings-toggle"))
    '';
  };
}
