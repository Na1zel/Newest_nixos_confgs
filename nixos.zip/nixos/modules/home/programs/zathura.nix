{ ... }:

{
  programs.zathura.enable = true;
}
